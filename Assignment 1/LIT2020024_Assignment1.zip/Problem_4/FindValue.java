public class FindValue {
    public static void main(String[] args) {

        System.out.print("Value of ( 10 & 50 ) : ");
        System.out.println(10 & 50);

        System.out.print("Value of ( 30 | 40 ) : ");
        System.out.println(30 | 40);

        System.out.print("Value of '~ 50' : ");
        System.out.println(~50);

        System.out.print("Value of ( 60 >> 3 ) : ");
        System.out.println(60 >> 3);

        System.out.print("Value of ( 70 << 8 ) : ");
        System.out.println(70 << 8);

        System.out.print("Value of ( 50 >>> 2 ) : ");
        System.out.println(50 >>> 2);

    }
}
